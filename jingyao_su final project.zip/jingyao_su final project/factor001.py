import sys
sys.path.append("/home/quant/work/code/share/common/")

import logging

from model_base import FactorModelBase
from quant_funcs import *

logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)



class FactorModel(FactorModelBase):
    def __init__(self,cfg):
        super().__init__(cfg)

        '''
        get params you set in config_factor_xxx.py
        '''
        self.n = cfg['params'].get('nday',20)

        self.type = cfg['params'].get('type',0)

        self.k = cfg['params'].get('k',0.2)


        '''
        load data you need
        '''
        self.high = self.dataloader.load_dailydata('high_adj')
        self.low = self.dataloader.load_dailydata('low_adj')
        self.clse_yes = self.dataloader.load_dailydata('close_adj').shift()
        self.open = self.dataloader.load_dailydata('open_adj')
        self.volume = self.dataloader.load_dailydata('volume')
        self.vwap = self.dataloader.load_dailydata('vwap_adj')
        self.turn_yes = self.dataloader.load_dailydata('S_DQ_TURN').shift()


        '''
        因子公式：
        factor =  (ts_rank((self.volume / self.adv20), 20) * ts_rank((-1 * delta(self.clse, 7)), 8)) 
        '''


        # self.returns = self.open / self.clse.shift(1) - 1
        # self.returns_s = self.returns.where(self.returns < 0)
        # # self.amp_df = correlation(self.returns_s, self.turn.shift(1), window = 20)
        # self.amp_df = self.returns.where(self.returns<0).rolling(window=10,min_periods=1).corr(self.turn.shift())
        logger.info(f"{cfg['factor_id']} done with initialization")



    def daily_handler(self, date_idx) -> pd.Series:
        date_now = self.trading_dates[date_idx]
        date_n = self.trading_dates[date_idx - self.n]

        tmp_opn_df = self.open.loc[date_n:date_now]
        tmp_clse_yes_df = self.clse_yes.loc[date_n:date_now]
        tmp_turn_yes_df = self.turn_yes.loc[date_n:date_now]

        night_ret = tmp_opn_df/tmp_clse_yes_df - 1
        factor_thisday = night_ret.where(night_ret<0).corrwith(tmp_turn_yes_df)


        factor_thisday = factor_thisday.replace([np.inf, -np.inf], np.nan)

        return factor_thisday
#以下是调用函数和的示例
# cfg = {
#     'params': {
#         'nday': 20,
#         'type': 0,
#         'k': 0.2,
#     },
#     'factor_id': 'example_factor',
#     'meta_dir': '/path/to/meta_dir'  # 添加 meta_dir
# }
#
# factor_model = FactorModel(cfg)
# factor_values = factor_model.calculate_factor()