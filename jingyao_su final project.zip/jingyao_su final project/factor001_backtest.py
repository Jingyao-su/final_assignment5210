config = {
  "ret":"/home/quant/work/data/next_ret/next_ret_0939.pkl",
  "barra_dir": "/home/quant/work/data/barra_data",

  "date":{
    "start_date": "20170104",
    "end_date": "20230530"
  },

  "factors": [
    {
      "factor_id": "factor_model_my009",
      "factor_values_file": "/home/quant/work/code/many/factor_values/factor_model_factor001.csv",
      "result_save_path": "/home/quant/work/code/0_final_factor/backtest_result",
      "weights": "rank",  # "alpha"
      "mode": "simple",  # "complex"

    },




  ]
}