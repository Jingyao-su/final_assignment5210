config = \
  {
  "dir":{
    "data_dir": "/home/quant/work/data",
    "meta_dir": "/home/quant/work/data/meta",

    "factor_model_files_dir": "/home/quant/work/code/many/factor_model_factor001",#py文件所在目录
    "result_save_path": "/home/quant/work/code/0_final_factor/factor_values"#运算结果存储路径
  },

  "date": {
    "start_date": "20170104",
    "end_date": "20230530"
  },

  "factors": [
     {
       "factor_id": "factor_model_my009",#给你的因子取个名字，自定义的，不影响程序运行
       "factor_model_file": "factor_model_my009",#py文件文件名
       "params": {},#可选。你的因子计算需要的参数，如你的因子是近 m 天 价格和成交量的相关系数，在这里给出m的值。
       "operators":[]#可选。你的因子在初步计算完之后，是否需要做一个op，（如转换成横截面的序、时序的序、zscore、中性化等等）
     },



  ]
}